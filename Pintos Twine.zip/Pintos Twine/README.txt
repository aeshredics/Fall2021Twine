The "Knighthood" html file and "audio" folder need to extracted to the same location or else the Twine's audio will not load.
There is a singular image that should work as long as Github is not down.